import "./App.css";
import React from "react";
import { CardContext } from "./context/context";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/navbar";
import Home from "./components/pages/Home";
import image from "../src/assets/images/img-2.jpg";
import image1 from "../src/assets/images/img-3.jpg";
import Cards from "./components/Cards";

function App() {
  // const cardcontext = CardContext;
  // const cards = [
  //   {
  //     id: 1,
  //     src: image,
  //     text: "explore the hidden wtarfall in the Amazon",
  //   },
  //   { id: 2, src: image1, text: "explore the hidden wtarfall in the Amazon" },
  //   {
  //     id: 3,
  //     src: image1,
  //     text: "explore the hidden wtarfall in the Amazon",
  //   },
  // ];

  return (
    <>
      {/* <cardcontext.Provider value={{Cards:cards}}>
        <Cards/>
      </cardcontext.Provider> */}
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}
export default App;
