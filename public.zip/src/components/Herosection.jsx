import Video from "../assets/videos/video-2.mp4";
import "./Herosection.css";
import "../App.css";
const Hero = () => {
  return (
    <div className="hero-container">
      <video src={Video} type="video/mp4" autoPlay loop muted />
      <h1>Adventure Awaits</h1>
      <p>what are you waiting for</p>
      <div className="hero-btns">
        <button className="btns btn btn--outline btn--large">
          Get started
        </button>

        <button className="btns btn btn--primary btn--large">
          Watch trailer <i className="far fa-play-circle" />
        </button>
      </div>
    </div>
  );
};

export default Hero;
