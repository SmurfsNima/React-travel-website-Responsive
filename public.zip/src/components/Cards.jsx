
import Carditem from "./Carditem";
import "./Cards.css";
import { useContext } from "react";
import { CardContext } from "../context/context.js";
import image from "../assets/images/img-2.jpg";
import image3 from "../assets/images/img-3.jpg";
import image4 from "../assets/images/img-4.jpg";
const Cards = () => {
  const cardscontext = useContext(CardContext)
  console.log(cardscontext);
  return (
    <div className="cards">
      <h1>Check Out these EPIc Destinations!</h1>
      <div className="cards__container">
        <div className="cards__wrapper">
          <ul className="cards__items">
            {/* {cardscontext.Cards.map((p,index)=>(
              <Carditem key={index} src={p.src} text={p.text}  path="/services"
              label="Adventure" />
            ))} */}
            <Carditem
              src={image}
              text="explore the hidden wtarfall in the Amazon"
              path="/services"
              label="Adventure"
            />
            <Carditem
              src={image3}
              text="explore the hidden wtarfall in the Amazon"
              path="/services"
              label="Adventure"
            />
            <Carditem
              src={image4}
              text="explore the hidden wtarfall in the Amazon"
              path="/services"
              label="Adventure"
            />
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Cards;
