import Cards from "../Cards";
import Hero from "../Herosection";
const Home = () => {
  return (
    <>
      <Hero />
      <Cards/>
    </>
  );
};

export default Home;
